<div style="position:inherit;margin-top:100px;background-color:#8cb501;width:980px;height:180px;">
<div  class="under-foot"><style>
 .under-foot
 {
 width:200px;height:100px;float:left;margin:20px;color:white;font-size:16px;
 }
 .under-foot li a 
 {
 color:#666;
 color:white;
 }
 .under-foot li a :hover
 {
 color:white;
 }
 </style>
 <ul>
 <li><a href="index.php">Home</a></li>
 <li><a href="aboutus.php">About</a></li>
 <li><a href ="registration.php">Register</a></li>
 <li><a href="aboutus.php#achievements">Achievements</a></li>
 
</ul> 
 
 </div>
  <div class="under-foot">
  <ul>
 <li><a href="news.php">News</a></li>
 <li><a href="downloads.php">Downloads</a></li>
 <li><a href="aboutus.php#membership">Membership</a></li>
 <li><a href="aboutus.php#objective">Objective</a></li>
 
</ul> 
  </div>
   <div class="under-foot">
   <ul>
 <li><a href="articles.php">Articles</a></li>
 <li><a href="allmembers.php">blog</a></li>
 <li><a href="officebearers.php">Office Bearers</a></li>
 <li><a href="contactus.php">Contact us</a></li>
 
</ul> 
   </div>
    <div class="under-foot"><ul>
 <li><a href="">Kerala finance</a></li>
 <li><a href="">ISM</a></li>
 <li><a href="">Kerala PSC</a></li>
 <li><a href="">A G Kerala</a></li>
 
</ul> </div>
<div align="center" style="font-size:15px;color:white;">powered by<b> <a href="http://www.nintriva.com/">Nintriva Wireless</a></b></div>
	</div>
	