<?php
session_start();
if(isset($_POST['submit']))
	{
	$query=$_POST['query'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$email1='kgagmoftsr@gmail.com';
	$email2='kgagmof1983@gmail.com';
	//mail function here//
	
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Corporate Plus Template by Templatesperfect.com -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" href="jquery.jcarousel.css" type="text/css" media="all" />
<title>Corporate Plus Business Template</title>

	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.jcarousel.pack.js"></script>
	<script type="text/javascript" src="js/func.js"></script>

<!-- Begin DropDown -->
      
<script type="text/javascript">
$(function(){
   $("ul.dropdown li").hover(function(){
        $(this).addClass("hover");
        $('ul:first',this).css('visibility', 'visible');
    
    }, function(){
   $(this).removeClass("hover");
   $('ul:first',this).css('visibility', 'hidden');
});
$("ul.dropdown li ul li:has(ul)").find("a:first").append(" &raquo; ");
});
</script>

</head>

<body>

<div id="header">

<div id="logo"></div>

<div id="social">
  <a href="#"><img src="images/facebook.png" width="40" height="40" alt="facebook" /></a>
  <a href="#"><img src="images/twitter.png" width="40" height="40" alt="twitter" /></a>
  <a href="#"><img src="images/linkedin.png"  width="40" height="40" alt="linkedin" /></a>
  <a href="#"><img src="images/rss.png"  width="40" height="40" alt="email" /></a>
</div>

</div>
<?php 
include('menu.php');
?>


<style>
#content p
{
text-indent:25px;
text-align:justify;

}
#content li
{
margin:10px;

}
</style>
<div align="center" style="margin-top:100px">
<form action="" method="post">
<table>
<tr><td> your e-mail id </td><td><input type="text" name="email" size="35"></td></tr>
<tr><td> contact number</td><td><input type="text" name="phone" size="35" ></td></tr>
<tr><td>your query</td><td><textarea name="query" rows="10" cols="30"></textarea></td></tr>
<tr><td colspan="2" align="center"><input type="submit" name="submit" value="Ask"></td></tr></table>
</form>
<hr/>
<div style="color:black">
KGAGMOF<br/>
PARAMESWARI AYURVEDA VAIDYASALA ,<br/>
NEAR GOVT AYURVEDA COLLEGE,<br/>
THIRUVANTHAPURAM-1<br/>
mail:-kgagmoftsr@gmail.com,kgagmof1983@gmail.com<br/>
visit our blog:-kgagmof.blogspot.com
</div>
</div>

</body>
</html>
