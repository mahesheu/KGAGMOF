<?php
//$conn=mysql_connect("localhost","alraisil_kgag","s&3TR(aE2IxN");
$conn=mysql_connect("localhost","root","");
mysql_select_db('alraisil_kgagmof',$conn);
mysql_select_db('kgagmof',$conn);
?>