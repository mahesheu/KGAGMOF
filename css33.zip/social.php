<div id="social">
  <a href="http://www.facebook.com/KGAGMOF" target="_blank"><img src="images/facebook.png" width="40" height="40" alt="facebook" onmouseover="this.src='images/facebook1.png'" onmouseout="this.src='images/facebook.png'"  /></a>
  <a href="http://twitter.com/#!/KGAGMOF" target="_blank"><img src="images/twitter.png" width="40" height="40" alt="twitter" onmouseover="this.src='images/twitter1.png'" onmouseout="this.src='images/twitter.png'" /></a>
  
  <a href="http://kgagmof.blogspot.com/" target="_blank"><img src="images/blog1.png"  width="40" height="40" alt="email" onmouseover="this.src='images/blog2.png'" onmouseout="this.src='images/blog1.png'" /></a>
</div>