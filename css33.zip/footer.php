<div id="footerWrap">
<!--- Footer Begin -->
    <div style="position:inherit;margin-top:100px;background-color:#8cb501;width:980px;height:180px;">
    <div  class="under-foot"><style>
     .under-foot
     {
     width:200px;height:100px;float:left;margin:20px;color:white;font-size:16px;
     }
     .under-foot li a 
     {
     color:#666;
     color:white;
     }
     .under-foot li a :hover
     {
     color:white;
     }
     </style>
     <ul>
     <li><a href="index.php">Home</a></li>
     <li><a href="aboutus.php">About</a></li>
     <li><a href ="registration.php">Register</a></li>
     <li><a href="aboutus.php#achievements">Achievements</a></li>
     
    </ul> 
     
     </div>
      <div class="under-foot">
      <ul>
     <li><a href="news.php">News</a></li>
     <li><a href="downloads.php">Downloads</a></li>
     <li><a href="aboutus.php#membership">Membership</a></li>
     <li><a href="aboutus.php#objective">Objective</a></li>
     
    </ul> 
      </div>
       <div class="under-foot">
       <ul>
     <li><a href="articles.php">Articles</a></li>
     <li><a href="allmembers.php">blog</a></li>
     <li><a href="officebearers.php">Office Bearers</a></li>
     <li><a href="contactus.php">Contact us</a></li>
     
    </ul> 
       </div>
        <div class="under-foot">
    	<span style="color:#DDD; font-size:12px;">Other Links:</span>
        <ul style="padding-top:5px;">
         <li><a href="http://www.finance.kerala.gov.in/" target="_blank">Kerala finance</a></li>
         <li><a href="http://ism.kerala.gov.in/" target="_blank">ISM</a></li>
         <li><a href="http://www.keralapsc.org/" target="_blank">Kerala PSC</a></li>
         <li><a href="http://agker.cag.gov.in/" target="_blank">A G Kerala</a></li>
	    </ul>
     </div>
     
<div align="center" style="font-size:15px;color:white;">powered by<b> <a href="http://www.nintriva.com/" target="_blank">Nintriva Wireless</a></b></div>
<div style="position:relative;width:200px;height:40px;bottom:40px;left:40px;">
 <a href="http://www.facebook.com/KGAGMOF" target="_blank"><img src="images/facebook.png" width="40" height="40" alt="facebook" onmouseover="this.src='images/facebook1.png'" onmouseout="this.src='images/facebook.png'"  /></a>
 <a href="http://twitter.com/#!/KGAGMOF" target="_blank"><img src="images/twitter.png" width="40" height="40" alt="twitter" onmouseover="this.src='images/twitter1.png'" onmouseout="this.src='images/twitter.png'" /></a>
<a href="http://kgagmof.blogspot.com/" target="_blank"><img src="images/blog1.png"  width="40" height="40" alt="email" onmouseover="this.src='images/blog2.png'" onmouseout="this.src='images/blog1.png'" /></a>
</div>      
	  </div>
<!--Footer End-->
</div>