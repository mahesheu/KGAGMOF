<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" 
      type="image/png" 
      href="images/rel.jpg">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" href="jquery.jcarousel.css" type="text/css" media="all" />
<title>KGAGMOF</title>

	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.jcarousel.pack.js"></script>
	<script type="text/javascript" src="js/func.js"></script>

<!-- Begin DropDown -->
      
<script type="text/javascript">
$(function(){
   $("ul.dropdown li").hover(function(){
        $(this).addClass("hover");
        $('ul:first',this).css('visibility', 'visible');
    
    }, function(){
   $(this).removeClass("hover");
   $('ul:first',this).css('visibility', 'hidden');
});
$("ul.dropdown li ul li:has(ul)").find("a:first").append(" &raquo; ");
});
</script>

</head>

<body>

<div id="header">

<div id="logo"></div>
<?php
//include('social.php');
?>

</div>
<?php
include('menu.php');
?>
<div id="content"><!-- content -->
<style>
#content p
{
text-indent:25px;
text-align:justify;

}
#content li
{
margin:10px;

}
h2
{
color:green;
text-align:center;
}
</style>
<style>
img
{
border:1px solid #666;
}
</style>
<div align="center"><h1>Our Leaders</h1></div>
<hr/>
<div align="center"><h2>State Leaders</h2></div>
<table width="650px" >
<tr><td><img src="images/1.jpg"/></td><td align="center"><b>Dr A Jayan</b><br/>President , state comitee</td><td>9447465659</td></tr>
<tr><td><img src="images/2.jpg"/></td><td align="center"><b>Dr V.V Anil kumar</b><br>Vice President , state comitee</td><td>9448882370</td></tr>
<tr><td><img src="images/3.jpg"/></td><td align="center"><b>Dr Baiju.K.V</b><br/>secretary,state comitee</td><td>9447656268</td></tr>
</table>

<br/><br/>
<table width="650px" >
<tr><td><img src="images/4.jpg"/></td><td align="center"><b>Dr N.P.Mathew</b><br/>Joint secretary,State comitee</td><td>9447109375</td></tr>
<tr><td><img src="images/5.jpg"/></td><td align="center"><b>Dr Sabeer Ali.K.M</b><br/>Joint secretary,State comitee</td><td>9447942472</td></tr>
<tr><td><img src="images/6.jpg"/></td><td align="center"><b>Dr .Vaheedha Beegum.A.K </b><br/>Joint secretary,State comitee</td><td>9446663144</td></tr>
</table>



<br/><br/>
<table width="650px" >
<tr><td><img src="images/9.jpg"/></td><td align="center"><b>Dr Sukesh.K.S.</b><br/>Treasurer</td><td>9447245809</td></tr>
<tr><td><img src="images/7.jpg"/></td><td align="center"><b>Dr Durga S.R</b><br/>Managing Editor</td><td>944745600</td></tr>
<tr><td><img src="images/8.jpg"/></td><td align="center"><b>Dr Haridas .P</b><br/>Editor</td><td>9496749781</td></tr>
</table>
<br/><br/>
<div align="center"><h2>Zonal Leaders</h2></div>
<h3>South zone</h3>
<table width="650px" >
<tr><td width="100px"><img src="images/sz1.jpg"/></td><td align="center"><b>Dr Ajayakumar S.S</b><br/>Zonal president</td><td>9495184626</td></tr>
<tr><td <td width="100px"><img src="images/sz2.jpg"/></td><td align="center"><b>Dr Prasannan S</b><br/>Zonal secretary</td><td>9448882370</td></tr>
</table>
<h3>Central zone</h3>
<table width="650px"  >
<tr><td width="100px"><img src="images/mz1.jpg"/></td><td align="center"><b>Dr S. Shibu</b><br/>Zonal president</td><td>9847363676</td></tr>
<tr><td width="100px"><img src="images/mz2.jpg"/></td><td align="center"><b>Dr Devidas A.K</b><br/>Zonal secretary</td><td>9895061349</td></tr>
</table>
<h3>North zone</h3>
<table width="650px"  >
<tr><td  width="100px"><img src="images/n1.jpg"/></td><td align="center"><b>Dr A. Ramachandran</b><br/>Zonal president</td><td>9446083513</td></tr>
<tr><td  width="100px"><img src="images/nz2.jpg"/></td><td align="center"><b>Dr P Raghuprasad </b><br/>Zonal secretary</td><td>9447680477</td></tr>
</table>
<hr/>
<div align="center"><h2>District leaders</h2></div>
<hr/>
<table width="650px" style="margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Thiruvanathapuram</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/def.jpg"/></td><td align="center"><b>Dr Pravith N.K</b><br/>District President</td><td>9946431132</td></tr>
<tr><td  width="100px"><img src="images/tvm2.jpg"/></td><td align="center"><b>Dr Rahul R.P </b><br/>District Secretary</td><td>9847567277</td></tr>
</table>
<table width="650px" style=" margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Kollam</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/klm1.jpg"/></td><td align="center"><b>Dr Ajithan M.N</b><br/>District President</td><td>9349134935</td></tr>
<tr><td  width="100px"><img src="images/klm2.jpg"/></td><td align="center"><b>Dr Pramod</b><br/>District Secretary</td><td>9447992845</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Pathanamthitta</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/sz1.jpg"/></td><td align="center"><b>Dr Ajayakumar S.S</b><br/>District President</td><td>9495184626</td></tr>
<tr><td  width="100px"><img src="images/pat2.jpg"/></td><td align="center"><b>Dr Shiju Mathew</b><br/>District Secretary</td><td>9447309348</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Alappuzha</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/apza01.jpg"/></td><td align="center"><b>Dr Benazir K.T</b><br/>District President</td><td>9447212101</td></tr>
<tr><td  width="100px"><img src="images/apza02.jpg"/></td><td align="center"><b>Dr Jayeshkumar P.D </b><br/>District Secretary</td><td>9447759897</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Kottayam</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/kt1.jpg"/></td><td align="center"><b>Dr Sreekumar P.S</b><br/>District President</td><td>9495514115</td></tr>
<tr><td  width="100px"><img src="images/kt2.jpg"/></td><td align="center"><b>Dr Sudarshanan D </b><br/>District Secretary</td><td>9495823623</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Eranakulam</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/ekm1.jpg"/></td><td align="center"><b>Dr Lovely Mathew</b><br/>District President</td><td>9961630525</td></tr>
<tr><td  width="100px"><img src="images/ekm2.jpg"/></td><td align="center"><b>Dr Jayakrishnan K.V.P </b><br/>District Secretary</td><td>9447475229</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Idukki<hr/></h2></td></tr>
<tr><td  width="100px"><img src="images/ik1.jpg"/></td><td align="center"><b>Dr Hameed CI</b><br/>District President</td><td>9447613418</td></tr>
<tr><td  width="100px"><img src="images/def.jpg"/></td><td align="center"><b>Dr Sheeja UB</b><br/>District Secretary</td><td>9446470142</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><h2><hr/>Thrissur<hr/></h2></td></tr>
<tr><td  width="100px"><img src="images/tsr1.jpg"/></td><td align="center"><b>Dr Satish M</b><br/>District President</td><td>9847390706</td></tr>
<tr><td  width="100px"><img src="images/tsr2.jpg"/></td><td align="center"><b>Dr Roy Joseph </b><br/>District Secretary</td><td>9447716255</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Palakkad</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/pkd1.jpg"/></td><td align="center"><b>Dr Sabeer Ali K.M</b><br/>District President</td><td>9447942472</td></tr>
<tr><td  width="100px"><img src="images/pkd2.jpg"/></td><td align="center"><b>Dr Jayakrishnan P </b><br/>District Secretary</td><td>9447923009</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Malappuram</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/mp1.jpg"/></td><td align="center"><b>Dr Abdul Rasheed V.P</b><br/>District President</td><td>9447106325</td></tr>
<tr><td  width="100px"><img src="images/def.jpg"/></td><td align="center"><b>Dr Anoop V.A</b><br/>District Secretary</td><td>9349718850</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Wayanad</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/w2.jpg"/></td><td align="center"><b>Dr Sureshkumar N</b><br/>District President</td><td>9447385957</td></tr>
<tr><td  width="100px"><img src="images/w1.jpg"/></td><td align="center"><b>Dr Aby Philip</b><br/>District Secretary</td><td>9961327164</td></tr>
</table>

<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Kozhikode<hr/></h2></td></tr>
<tr><td  width="100px"><img src="images/koz1.jpg"/></td><td align="center"><b>Dr Anilkumar T.K</b><br/>District President</td><td>9447390036</td></tr>
<tr><td  width="100px"><img src="images/def.jpg"/></td><td align="center"><b>Dr Mansoor K.M </b><br/>District Secretary</td><td>9495857231</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Kanoor</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/def.jpg"/></td><td align="center"><b>Dr Sareena A.N </b><br/>District President</td><td>9495929628</td></tr>
<tr><td  width="100px"><img src="images/def.jpg"/></td><td align="center"><b>Dr Vishwanathan V.K</b><br/>District Secretary</td><td>9446654599</td></tr>
</table>
<table width="650px" style="  margin-top:10px">
<tr><td align="center" colspan="3"><hr/><h2>Kasargode</h2><hr/></td></tr>
<tr><td  width="100px"><img src="images/kg1.jpg"/></td><td align="center"><b>Dr Leena B</b><br/>District President</td><td>9447693449</td></tr>
<tr><td  width="100px"><img src="images/kg2.jpg"/></td><td align="center"><b>Dr Sreeni R </b><br/>District Secretary</td><td>9447792652</td></tr>
</table>
</div><!-- end content -->
<?php
include('sidecontent.php');
?>
</body>
</html>
