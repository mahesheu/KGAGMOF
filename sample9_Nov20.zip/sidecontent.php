<div id="sidebar"><!-- sidebar -->

<h3>Favourites</h3>

    <div class="navcontainer">
    <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="gallary.php">photo Gallery</a></li>
    <li><a href="downloads.php">Ayur Digest</a></li>
    <li><a href="officebearers.php">Office bearers</a></li>
    <li><a href="contact.php">Mail us</a></li>
    </ul>
    </div>

<h3>Navigations</h3>

    <div class="navcontainer">
    <ul>
    <li><a href="http://www.kgagmof.blogspot.com/" target="_blank">Our Blog</a></li>
    <li><a href="http://ism.kerala.gov.in/" target="_blank">ISM  </a></li>
    <li><a href="http://www.finance.kerala.gov.in/" target="_blank">Kerala Finance</a></li>
    <li><a href="http://agker.cag.gov.in/" target="_blank">A G Kerala</a></li>
    <li><a href="http://www.keralapsc.org/" target="_blank">Kerala PSC</a></li>
    </ul>
    </div>

<h3>Inspirational Quotes</h3>

<p class="sidebar_box">&quot;A   physician is obligated to consider more than a diseased organ, more   even than the whole man - he must view the man in his world&quot;.